# soundr
A widget which alerts the user of loud sounds in their environment.
